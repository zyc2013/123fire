#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <tf/transform_broadcaster.h>
#include <sstream>
//#include "std_msgs/String.h"
#include "std_msgs/Int16.h"

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction>MoveBaseClient;

int main(int argc, char** argv)
{
    ros::init(argc, argv, "navigation_goals");

    ros::NodeHandle n;
    //ros::Publisher sendgoalresult_pub = n.advertise<std_msgs::String>("result", 10);
    ros::Publisher sendgoalresult_pub = n.advertise<std_msgs::Int16>("result", 10);

    //std_msgs::String msgs,msgf;
    std_msgs::Int16 msgs,msgf;
    /*std::stringstream succeeded,failed;
    succeeded << "a" ;
    failed << "b" ;
    succeeded << "1" ;
    failed << "2" ;
    msgs.data = succeeded.str();
    msgf.data = failed.str();
    */
    msgs.data = 1;
    msgf.data = 2;


    MoveBaseClient ac("move_base", true);
    
    while(!ac.waitForServer(ros::Duration(5.0)))
	{
	   ROS_INFO("Waiting for the move_base action server");	
	} 
    move_base_msgs::MoveBaseGoal goal;

    goal.target_pose.header.frame_id = "map";
    goal.target_pose.header.stamp = ros::Time::now();
    
    goal.target_pose.pose.position.x = -4.893;
    goal.target_pose.pose.position.y = 5.911;
    goal.target_pose.pose.orientation.z = -0.790;
    goal.target_pose.pose.orientation.w = 0.613;

    ROS_INFO("Sending goal");
    ac.sendGoal(goal);
    
    ac.waitForResult();
    if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED){
       //ROS_INFO("%s", msgs.data.c_str());
       ROS_INFO("%d", msgs.data);
       sendgoalresult_pub.publish(msgs);
    }
    else
    {
        //ROS_INFO("%s", msgf.data.c_str());
        ROS_INFO("%d", msgf.data);
        sendgoalresult_pub.publish(msgf);
    } 
    return 0;
}
