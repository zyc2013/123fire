#!/bin/bash
sleep 0

#ps -aux
while true
do 

sleep 2
if test $( ps -a|grep python|wc -l) -eq 0
#yi jian ce chuan kou hao zuo wei jian ce jie guo 
then
echo 'no'
gnome-terminal --window -e 'bash -c "echo "ubuntu" |rosrun rosserial_python serial_node.py;'
else
echo 'yes'
fi

done
exit 0
