#include "ros/ros.h"
#include <sstream>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/opencv.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <string.h>
#include <std_msgs/String.h>
#include "std_msgs/Int16.h"
#include <iostream>
#include <stdio.h>
#include <Eigen/Core>
#include <Eigen/Dense>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include "geometry_msgs/Twist.h"
#include <cstdio>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <fcntl.h>
#include <unistd.h>
int g_TopPointstart = 0;
int g_TopPointend = 0;
int device_;
int H_min = 0;
int H_max = 60;
int S_min = 20;
int S_max = 100;
int I_min = 100;
int I_max = 255;
#define PI 3.14159265358979323846
using namespace cv;
using namespace std;
Eigen::Matrix4d Qc;
Eigen::Vector4d delta,ans;
int trash=0;
int zyx=1;
Point center1 (0,0);
Point center2 (0,0);
Point center3(0,0);
Point center4(0,0);
int redThre =10; // 115~135  10
int saturationTh = 7; //55~65  7
bool command=false;
bool command1=false;
void center_g(const vector<Point> contour,Point &center);
Point CheckColor1(Mat &inImg);
Point CheckColor2(Mat &inImg);
Point Check1(Mat &inImg);
Point Check2(Mat &inImg);
void chatterCallback(const std_msgs::String::ConstPtr& key)
{
cout<<"1111111111111"<<endl;
if (key->data == "a")
{
cout<<"22222222222222"<<endl;
command=true;
}
else 
{
command=false;
}
}
void chatterCallback1(const std_msgs::Int16& verify_msg)
{
if (verify_msg.data == 2)
{
cout<<"555555555555555"<<endl;
command1=true;
}
else
{
command1=false;
}
}
bool LinenableExpose(bool flag){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id = V4L2_CID_EXPOSURE_AUTO;
    if(flag)
        ctrl.value = V4L2_EXPOSURE_AUTO;
    else
        ctrl.value = V4L2_EXPOSURE_MANUAL;
    ret = ioctl(device_, VIDIOC_S_CTRL, &ctrl);
    if (ret < 0){
        std::cout<< "set camera expose1 failed!" << std::endl;
        return false;
    }
    return true;
}

bool LinsetExpose(int expose){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id = V4L2_CID_EXPOSURE_ABSOLUTE;
    ctrl.value = expose;
    ret = ioctl(device_, VIDIOC_S_CTRL, &ctrl);
    if (ret < 0){
        std::cout<< "set camera expose2 failed!" << std::endl;
        return false;
    }
    return true;
}
bool LinsetGain(int gain){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id = V4L2_CID_GAIN;
    ctrl.value = gain;
    ret = ioctl(device_, VIDIOC_S_CTRL, &ctrl);
    if (ret < 0){
        std::cout<< "set camera expose3 failed!" << std::endl;
        return false;
    }
    return true;
}
bool LinsetGamma(int gamma){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id = V4L2_CID_GAMMA;
    ctrl.value = gamma;
    ret = ioctl(device_, VIDIOC_S_CTRL, &ctrl);
    if (ret < 0){
        std::cout<< "set camera expose3 failed!" << std::endl;
        return false;
    }
    return true;
}
bool LinenableWriteBalance(bool flag){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id=V4L2_CID_AUTO_WHITE_BALANCE;
    if(flag)
        ctrl.value=V4L2_WHITE_BALANCE_AUTO;
    else
        ctrl.value=V4L2_WHITE_BALANCE_MANUAL;
    ret=ioctl(device_,VIDIOC_S_CTRL,&ctrl);
    if(ret<0){
        std::cout<<"set camera writeblance failed!"<<std::endl;
        return false;
    }
    return true;
}
int main(int argc, char **argv)
{
  ros::init(argc, argv, "talker");
  ros::NodeHandle n;
  ros::Publisher chatter_pub = n.advertise<geometry_msgs::Twist>("chatter", 1);
  ros::Rate loop_rate(10);
  int count = 0;
  ros::Subscriber sub2 = n.subscribe("verify", 1000, chatterCallback1);
  geometry_msgs::Twist cmd_msg;
    
    Mat rect1,rect2,src, R, T,E, F, RFirst, RSec, PFirst, PSec, canLeft,canLeft1,canLeft2,canRight,canRight1,canRight2,Q;
    Mat cameraMatrix1 = Mat(3, 3, CV_32FC1, Scalar::all(0));
    Mat distCoeffs1=Mat(1, 5, CV_32FC1,Scalar::all(0));
    Mat cameraMatrix2 = Mat(3, 3, CV_32FC1, Scalar::all(0));
    Mat distCoeffs2=Mat(1, 5, CV_32FC1,Scalar::all(0));
    Size imageSize(320,240);
    Rect validRoi[2], box,box2,box_result,box_result2;
    Mat rmapFirst[2], rmapSec[2], rviewFirst, rviewSec;
    int ss;
    Mat mapLx, mapLy,mapRx, mapRy;
        cameraMatrix1 = (Mat_<double>(3, 3) << 457.0318368103744, 0, 331.0365247986732,0, 457.1022755717155, 176.4294941404549,0, 0, 1);
    distCoeffs1 = (Mat_<double>(5, 1) << 0.01968812307996145,-0.05246126563481698,0.001502675615449003,0.0005427201715849649,-0.005518184314704255);
    cameraMatrix2 = (Mat_<double>(3, 3) << 456.5822039627947, 0, 318.2293934352507,0, 456.7708429649016, 178.9606902918353,0, 0, 1);
    distCoeffs2 = (Mat_<double>(5, 1) << 0.01628790637043522,-0.001997191968762123,0.0004516248832828489,0.0004308406227287013,-0.1017640155401076);

    T = (Mat_<double>(3, 1) << -60.02576523935617,0.08952069055888268,0.4256510957048559);
    R = (Mat_<double>(3,3) <<0.9999917835577945, -0.0007715223348657766, 0.003979644480082594,0.000782631068450324, 0.9999958000480408, -0.002790586836064505,-0.003977474765695553, 0.002793678500780549, 0.9999881874576931);
    Q=(Mat_<double>(4,4) <<1, 0, 0, -334.4535980224609,0, 1, 0, -178.0834274291992,0, 0, 0, 442.8440650054057,0, 0, 0.01665907536239501, -0.187288770155063);
    cout<<imageSize.width<<endl;
    stereoRectify(cameraMatrix1,distCoeffs1, cameraMatrix2,distCoeffs2, imageSize, R, T, RFirst,
                  RSec, PFirst, PSec, Q, 0, 1, imageSize, &validRoi[0], &validRoi[1]);
    for (size_t i=0;i<4;i++)
    {
        for(size_t j=0;j<4;j++)
        {
            Qc(i,j)=Q.at<double>(i,j);
        }
    }
    initUndistortRectifyMap(cameraMatrix1, distCoeffs1, RFirst, PFirst,
                            imageSize, CV_16SC2, rmapFirst[0], rmapFirst[1]);
    initUndistortRectifyMap(cameraMatrix2, distCoeffs2, RSec, PSec,
                            imageSize, CV_16SC2, rmapSec[0], rmapSec[1]);
    namedWindow("Control", CV_WINDOW_AUTOSIZE);
    cvCreateTrackbar("redThre", "Control", &redThre, 255);
    cvCreateTrackbar("saturationTh", "Control", &saturationTh, 255);
    
    
    VideoCapture cap;
    cap.open(0);
    cap.set(CV_CAP_PROP_FRAME_WIDTH, 2560);
    cap.set(CV_CAP_PROP_FRAME_HEIGHT, 720);
    if (!cap.isOpened())                         
    {
        return -1;
    }
    Mat frame,frame_L,frame_R;
    cap >> frame;  
    double fScale = 0.5;                               
    Size dsize = Size(frame.cols*fScale, frame.rows*fScale);
    Mat imagedst = Mat(dsize, CV_32S);
    resize(frame, imagedst, dsize);
    Rect leftRect(0, 0, 640, 360);
    Rect rightRect(640, 0, 640, 360);
    cout<<"trash1="<<trash<<endl;    device_=open("/dev/video0",O_RDWR);
    LinenableExpose(false);
    //LinenableWriteBalance(true);
    //LinsetExpose(0);//0
    //LinsetGain(16);
    //LinsetGamma(0);


  while (ros::ok())
  {
      cap >> frame;                          
      resize(frame, imagedst, dsize);        
      Mat leftImg,rightImg;
      imagedst(leftRect).copyTo(leftImg);
      imagedst(rightRect).copyTo(rightImg);
      Mat rectifyImageL2, rectifyImageR2;
      remap(leftImg, rectifyImageL2, rmapFirst[0], rmapFirst[1], INTER_LINEAR);
      remap(rightImg, rectifyImageR2, rmapSec[0], rmapSec[1], INTER_LINEAR);
      if(waitKey(1)=='q')
          break;
      //center3=center1;
      //center4=center2;
      //center1=CheckColor1(leftImg);
      //center2=CheckColor2(rightImg);
      center1=Check1(leftImg);
      center2=Check2(rightImg);
      float a,b,c,d,diff1,diff2;
      a=center1.x*center1.x+center1.y*center1.y;
      b=center2.x*center2.x+center2.y*center2.y;
      c=center3.x*center3.x+center3.y*center3.y;
      d=center4.x*center4.x+center4.y*center4.y;
      cout<<"center10="<<center1<<endl;
      cout<<"center20="<<center2<<endl;
      cout<<"center30="<<center3<<endl;
      cout<<"center40="<<center4<<endl;
      cout<<"a="<<a<<endl;
      cout<<"b="<<b<<endl;
      cout<<"c="<<c<<endl;
      cout<<"d="<<d<<endl;
      diff1=abs(a-c);
      diff1=sqrt(diff1);
      diff2=abs(b-d);
      diff2=sqrt(diff2);
      cout<<"diff1="<<diff1<<endl;
      cout<<"diff2="<<diff2<<endl;
      if(diff1>100&&diff2>100)
         {
           trash=0;
           cout<<"11111111111111"<<endl;
         }
      else
         {
           trash=1;
         }
      if(trash==0)
         { 
           center3=center1;
           center4=center2;
           trash=1;
           //cout<<"trash4="<<trash<<endl;
         }
      else
         {
           center3=center3;
           center4=center4;
         }   
      /*cout<<"center1="<<center1<<endl;
      cout<<"center2="<<center2<<endl;
      cout<<"center3="<<center3<<endl;
      cout<<"center4="<<center4<<endl;*/
      circle(leftImg, center3, 5, Scalar(0,0,255),-1);
      circle(rightImg, center4, 5, Scalar(0,0,255),-1);
      imshow("left",leftImg);
      imshow("right",rightImg);
      if(command1==true)
        {
           delta(0,0)=center1.x;
           delta(1,0)=center1.y;
           delta(2,0)=center1.x-center2.x;
           delta(3,0)=1.0;
           ans=Qc*delta;             
           cmd_msg.linear.x=ans(0,0)/ans(3,0);
           cmd_msg.linear.y=ans(1,0)/ans(3,0)+107;
           cmd_msg.linear.z=ans(2,0)/ans(3,0);
           if(cmd_msg.linear.x<700)
             {
                cmd_msg.angular.x=atan2(cmd_msg.linear.y,cmd_msg.linear.z)*180/PI;
                cmd_msg.angular.y=atan2(cmd_msg.linear.x,cmd_msg.linear.z)*180/PI;
                cmd_msg.linear.z=cmd_msg.linear.z-400;
                cout<<"x="<<cmd_msg.linear.x<<"y="<<cmd_msg.linear.y<<"z="<<cmd_msg.linear.z<<endl;
                chatter_pub.publish(cmd_msg);
                cout<<"cmd_msg.angular.x="<<cmd_msg.angular.x<<endl;
                cout<<"cmd_msg.angular.y="<<cmd_msg.angular.y<<endl;
                command1=false;
             }
          /*if(center3.x!=0&&center3.y!=0&&center4.x!=0&&center4.y!=0)
             {
           delta(0,0)=center3.x;
           delta(1,0)=center3.y;
           delta(2,0)=center3.x-center4.x;
           delta(3,0)=1.0;
           ans=Qc*delta;             
           cmd_msg.linear.x=ans(0,0)/ans(3,0);
           cmd_msg.linear.y=ans(1,0)/ans(3,0)+107;
           cmd_msg.linear.z=ans(2,0)/ans(3,0);
           //if(cmd_msg.linear.x<700)
             //{
                cmd_msg.angular.x=atan2(cmd_msg.linear.y,cmd_msg.linear.z)*180/PI;
                cmd_msg.angular.y=atan2(cmd_msg.linear.x,cmd_msg.linear.z)*180/PI;
                cout<<"x="<<cmd_msg.linear.x<<"y="<<cmd_msg.linear.y<<"z="<<cmd_msg.linear.z<<endl;
                cmd_msg.linear.z=cmd_msg.linear.z-400;
                
                chatter_pub.publish(cmd_msg);
                cout<<"cmd_msg.angular.x="<<cmd_msg.angular.x<<endl;
                cout<<"cmd_msg.angular.y="<<cmd_msg.angular.y<<endl;
                command1=false;*/
              //}
              
               else
                {
                   cmd_msg.linear.x=0;
                   cmd_msg.linear.y=0;
                   cmd_msg.linear.z=0;
                   cmd_msg.angular.x=0;
                   cmd_msg.angular.y=0;
                   chatter_pub.publish(cmd_msg);
                   cout<<"have received order but discover no fire!"<<endl;
                   command1=false;
                }
         }
    ros::spinOnce();
    loop_rate.sleep();
    ++count;
}
  return 0;
}
void center_g(const vector<Point> contour,Point &center)
{
    Moments mu;                                                
    mu = moments(contour,false);
    center.x=mu.m10/mu.m00;
    center.y=mu.m01/mu.m00;
}
Point CheckColor1(Mat &inImg)
{
    bool rule1=false;
    Mat fireImg;
    fireImg.create(inImg.size(), CV_8UC1);
    Mat multiRGB[3];
    int a = inImg.channels();
    split(inImg, multiRGB);
    for (int i = 0; i < inImg.rows; i++)
    {
        for (int j = 0; j < inImg.cols; j++)
        {
            float B, G, R;
            B = multiRGB[0].at<uchar>(i, j);
            G = multiRGB[1].at<uchar>(i, j);
            R = multiRGB[2].at<uchar>(i, j);
            float maxValue = max(max(B, G), R);
            float minValue = min(min(B, G), R);
            double S = (1 - 3.0*minValue / (R + G + B));//
            if (R > redThre &&R >= G && G>= B && S >((255 - R) * saturationTh / redThre))
            {
                fireImg.at<uchar>(i, j) = 255;
            }
            else
            {
                fireImg.at<uchar>(i, j) = 0;
            }
        }
    }
    medianBlur(fireImg, fireImg, 5);
    dilate(fireImg, fireImg, Mat(5, 5, CV_8UC1));
    imshow("1",fireImg);
    vector<vector<Point> > contours_left, Triangle_left;
    vector<Vec4i> hierarchy_L;
    vector<Point> approx_left;
    Point left_center1;
    vector<cv::Point2f> points2d1;
    findContours(fireImg, contours_left, hierarchy_L, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
    int tlsize = 0;
    for (int i = 0; i < contours_left.size(); i++)
    {
        approxPolyDP(contours_left[i], approx_left, 10, true);
        contourArea(contours_left[i]);

        if (contourArea(contours_left[i]) > tlsize)
        {
            tlsize = contourArea(contours_left[i]);
            Triangle_left.clear();
            center_g(contours_left[i], left_center1);
            Triangle_left.push_back(contours_left[i]);
        }
    }
    for (int i = 0; i < Triangle_left.size(); i++)
    {
        if (tlsize == contourArea(Triangle_left[i]))
        {
            center_g(Triangle_left[i], left_center1);
            RotatedRect rectangle = minAreaRect(Triangle_left[i]);
            Point2f vertex[4];
            rectangle.points(vertex);
            circle(inImg, left_center1, 5, Scalar(0,255,0),-1);
            drawContours(inImg, Triangle_left, -1, Scalar(255,0,0),3);
        }
        else
          {
            center3.x=0;
            center3.y=0;
          }
    }
    return left_center1;
}
Point CheckColor2(Mat &inImg)
{
    bool rule1=false;
    Mat fireImg;
    fireImg.create(inImg.size(), CV_8UC1);
    Mat multiRGB[3];
    int a = inImg.channels();
    split(inImg, multiRGB);
    for (int i = 0; i < inImg.rows; i++)
    {
        for (int j = 0; j < inImg.cols; j++)
        {
            float B, G, R;
            B = multiRGB[0].at<uchar>(i, j);
            G = multiRGB[1].at<uchar>(i, j);
            R = multiRGB[2].at<uchar>(i, j);
            float maxValue = max(max(B, G), R);
            float minValue = min(min(B, G), R);
            double S = (1 - 3.0*minValue / (R + G + B));//
            if (R > redThre &&R >= G && G>= B && S >((255 - R) * saturationTh / redThre))
            {
                fireImg.at<uchar>(i, j) = 255;
            }
            else
            {
                fireImg.at<uchar>(i, j) = 0;
            }
        }
    }
    medianBlur(fireImg, fireImg, 5);
    dilate(fireImg, fireImg, Mat(5, 5, CV_8UC1));
    imshow("2",fireImg);
    vector<vector<Point> > contours_left, Triangle_left;
    vector<Vec4i> hierarchy_L;
    vector<Point> approx_left;
    Point left_center1;
    vector<cv::Point2f> points2d1;
    findContours(fireImg, contours_left, hierarchy_L, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
    int tlsize = 0;
    for (int i = 0; i < contours_left.size(); i++)
    {
        approxPolyDP(contours_left[i], approx_left, 10, true);
        contourArea(contours_left[i]);

        if (contourArea(contours_left[i]) > tlsize)
        {
            tlsize = contourArea(contours_left[i]);
            Triangle_left.clear();
            center_g(contours_left[i], left_center1);
            Triangle_left.push_back(contours_left[i]);
        }
    }
    for (int i = 0; i < Triangle_left.size(); i++)
    {
        if (tlsize == contourArea(Triangle_left[i]))
        {
            center_g(Triangle_left[i], left_center1);
            RotatedRect rectangle = minAreaRect(Triangle_left[i]);
            Point2f vertex[4];
            rectangle.points(vertex);
            circle(inImg, left_center1, 5, Scalar(0,255,0),-1);
            drawContours(inImg, Triangle_left, -1, Scalar(255,0,0),3);
        }
        else
          {
            center4.x=0;
            center4.y=0;
          }
    }
    return left_center1;
}
Point Check1(Mat &inImg)
{
    Mat fireImg;
    fireImg.create(inImg.size(), CV_8UC1);
    Mat fireImg1;
    fireImg1.create(inImg.size(), CV_8UC1);
    double eps = 1.111e-016;
    double pi = 3.1416;
    double num = 0;
    double den = 0;
    double theta = 0;
    Mat multiRGB[3];
    int a = inImg.channels();
    split(inImg, multiRGB);
    for (int i = 0; i < inImg.rows; i++)
    {
        for (int j = 0; j < inImg.cols; j++)
        {
            float B, G, R, H, S, I;
            B = multiRGB[0].at<uchar>(i, j);
            G = multiRGB[1].at<uchar>(i, j);
            R = multiRGB[2].at<uchar>(i, j);
            float maxValue = max(max(B, G), R);
            float minValue = min(min(B, G), R);
            double S1 = (1 - 3.0*minValue / (R + G + B));//
            //if (R > redThre &&R >= G && G>= B && S >((255 - R) * saturationTh / redThre))
            if (R > redThre && R >= G && G >= B && S1 > 0.20 && S1 > (255 - R) / 20 && S1 >= ((255 - R)*saturationTh / redThre))
            {
                fireImg.at<uchar>(i, j) = 255;
            }
            else
            {
                fireImg.at<uchar>(i, j) = 0;
            }
            /*******************************************************************/
            B = B/255.0;
            G = G/255.0;
            R = R/255.0;
            num = 0.5*((R - G) + (R - B));
            den = sqrt((R - G)*(R - G) + (R - B)*(G - B));
            theta = acos(num / (den + eps));
            H = theta;
            if (B>G)
            {
                H = 2 * pi - H;
            }
            H = H / (2 * pi);
            num = min(min(R, G), B);
            den = R + G + B;
            if (den < eps)
            {
                den = eps;
            }
            S = 1 - 3 * num / den;
            if (S < eps)
            {
                H = 0;
            }
            I = (R + G + B) / 3.0;
            H = H * 360;
            S = S * 255;
            I = I * 255;
            if(H>=H_min&&H<=H_max&&S>=S_min&&S<=S_max&&I>=I_min&&I<=I_max)
            {
                fireImg1.at<uchar>(i, j) = 255;
            }
            else
            {
                fireImg1.at<uchar>(i, j) = 0;
            }
        }
    }
    medianBlur(fireImg, fireImg, 3);
    medianBlur(fireImg1, fireImg1, 3);//中值滤波
    dilate(fireImg, fireImg, Mat(5, 5, CV_8UC1));
    dilate(fireImg1, fireImg1, Mat(5, 5, CV_8UC1));
    Mat Final_Img;
    RotatedRect rect;
    Final_Img=fireImg&fireImg1;
    medianBlur(Final_Img, Final_Img, 3);//中值滤波
    //imshow("1fireImg",fireImg);
    //imshow("1fireImg1",fireImg1);
    //imshow("1Final_Img",Final_Img);
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    //findContours(Final_Img, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));
    findContours(Final_Img, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE, Point(0, 0));
    vector<vector<Point> > contours_poly(contours.size());
    if (contours.size() > 0)
    {
        double maxArea = 50;
        for (int index = 0; index < contours.size(); index++)
        {
            double area = contourArea(contours[static_cast<int>(index)]);
            if (area > maxArea)
            {
                rect = minAreaRect(contours[static_cast<int>(index)]);

            }
        }
        ellipse(inImg, rect, cv::Scalar(0, 255, 255), 2, 8);
        circle(inImg, rect.center, 5, Scalar(0,255,0),-1);
    }
    return rect.center;
}
Point Check2(Mat &inImg)
{
    Mat fireImg;
    fireImg.create(inImg.size(), CV_8UC1);
    Mat fireImg1;
    fireImg1.create(inImg.size(), CV_8UC1);
    double eps = 1.111e-016;
    double pi = 3.1416;
    double num = 0;
    double den = 0;
    double theta = 0;
    Mat multiRGB[3];
    int a = inImg.channels();
    split(inImg, multiRGB);
    for (int i = 0; i < inImg.rows; i++)
    {
        for (int j = 0; j < inImg.cols; j++)
        {
            float B, G, R, H, S, I;
            B = multiRGB[0].at<uchar>(i, j);
            G = multiRGB[1].at<uchar>(i, j);
            R = multiRGB[2].at<uchar>(i, j);
            float maxValue = max(max(B, G), R);
            float minValue = min(min(B, G), R);
            double S1 = (1 - 3.0*minValue / (R + G + B));//
            //if (R > redThre &&R >= G && G>= B && S >((255 - R) * saturationTh / redThre))
            if (R > redThre && R >= G && G >= B && S1 > 0.20 && S1 > (255 - R) / 20 && S1 >= ((255 - R)*saturationTh / redThre))
            {
                fireImg.at<uchar>(i, j) = 255;
            }
            else
            {
                fireImg.at<uchar>(i, j) = 0;
            }
            /*******************************************************************/
            B = B/255.0;
            G = G/255.0;
            R = R/255.0;
            num = 0.5*((R - G) + (R - B));
            den = sqrt((R - G)*(R - G) + (R - B)*(G - B));
            theta = acos(num / (den + eps));
            H = theta;
            if (B>G)
            {
                H = 2 * pi - H;
            }
            H = H / (2 * pi);
            num = min(min(R, G), B);
            den = R + G + B;
            if (den < eps)
            {
                den = eps;
            }
            S = 1 - 3 * num / den;
            if (S < eps)
            {
                H = 0;
            }
            I = (R + G + B) / 3.0;
            H = H * 360;
            S = S * 255;
            I = I * 255;
            if(H>=H_min&&H<=H_max&&S>=S_min&&S<=S_max&&I>=I_min&&I<=I_max)
            {
                fireImg1.at<uchar>(i, j) = 255;
            }
            else
            {
                fireImg1.at<uchar>(i, j) = 0;
            }
        }
    }
    medianBlur(fireImg, fireImg, 3);
    medianBlur(fireImg1, fireImg1, 3);//中值滤波
    dilate(fireImg, fireImg, Mat(5, 5, CV_8UC1));
    dilate(fireImg1, fireImg1, Mat(5, 5, CV_8UC1));
    Mat Final_Img;
    RotatedRect rect;
    Final_Img=fireImg&fireImg1;
    medianBlur(Final_Img, Final_Img, 3);//中值滤波
    //imshow("2fireImg",fireImg);
    //imshow("2fireImg1",fireImg1);
    //imshow("2Final_Img",Final_Img);
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    //findContours(Final_Img, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0));
    findContours(Final_Img, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_NONE, Point(0, 0));
    vector<vector<Point> > contours_poly(contours.size());
    if (contours.size() > 0)
    {
        double maxArea = 50;
        for (int index = 0; index < contours.size(); index++)
        {
            double area = contourArea(contours[static_cast<int>(index)]);
            if (area > maxArea)
            {
                rect = minAreaRect(contours[static_cast<int>(index)]);
            }
        }
        ellipse(inImg, rect, cv::Scalar(0, 255, 255), 2, 8);
        circle(inImg, rect.center, 5, Scalar(0,255,0),-1);
    }
    return rect.center;
}
