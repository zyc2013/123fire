#include "ros/ros.h"
#include <sstream>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/opencv.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <string.h>
#include <std_msgs/String.h>
#include "std_msgs/Int16.h"
#include <iostream>
#include <stdio.h>
#include <Eigen/Core>
#include <Eigen/Dense>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include "geometry_msgs/Twist.h"
#include <cstdio>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <fcntl.h>
#include <unistd.h>
int g_TopPointstart = 0;
int g_TopPointend = 0;
int device_;
void jianjiao(IplImage *pImage);
#define PI 3.14159265358979323846
using namespace cv;
using namespace std;
/*
 * 添加头文件：#include "std_msgs/Int64.h"
 * 改变消息类型
 * 查看stdmsgs数据里的data类型*/
Eigen::Matrix4d Qc;
Eigen::Vector4d delta,ans;
int zyx=1;
Point center1 (0,0);
Point center2 (0,0);
//Size Center1,Center2;
int redThre =50; // 115~135  20
int saturationTh = 30; //55~65  7
bool command=false;
bool command1=false;
void center_g(const vector<Point> contour,Point &center);
Point CheckColor0(Mat &inImg);
Point CheckColor1(Mat left);
Mat CheckColor3(Mat &inImg);
void chatterCallback(const std_msgs::String::ConstPtr& key)
{
cout<<"1111111111111"<<endl;
if (key->data == "a")
{
cout<<"22222222222222"<<endl;
command=true;
}
else 
{
command=false;
}
}
void chatterCallback1(const std_msgs::Int16& verify_msg)
{
if (verify_msg.data == 2)
{
cout<<"555555555555555"<<endl;
command1=true;
}
else
{
command1=false;
}
}
IplImage* get_ipl_roi(IplImage* src, CvRect rect)
{
    cvSetImageROI(src, rect);
    IplImage* tmp = cvCreateImage(cvSize(src->roi->width, src->roi->height), src->depth, src->nChannels);
    cvCopy(src, tmp, NULL);
    cvResetImageROI(src);
    return tmp;
}

bool LinenableExpose(bool flag){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id = V4L2_CID_EXPOSURE_AUTO;
    if(flag)
        ctrl.value = V4L2_EXPOSURE_AUTO;
    else
        ctrl.value = V4L2_EXPOSURE_MANUAL;
    ret = ioctl(device_, VIDIOC_S_CTRL, &ctrl);
    if (ret < 0){
        std::cout<< "set camera expose1 failed!" << std::endl;
        return false;
    }
    return true;
}

bool LinsetExpose(int expose){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id = V4L2_CID_EXPOSURE_ABSOLUTE;
    ctrl.value = expose;
    ret = ioctl(device_, VIDIOC_S_CTRL, &ctrl);
    if (ret < 0){
        std::cout<< "set camera expose2 failed!" << std::endl;
        return false;
    }
    return true;
}
bool LinsetGain(int gain){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id = V4L2_CID_GAIN;
    ctrl.value = gain;
    ret = ioctl(device_, VIDIOC_S_CTRL, &ctrl);
    if (ret < 0){
        std::cout<< "set camera expose3 failed!" << std::endl;
        return false;
    }
    return true;
}

bool LinenableWriteBalance(bool flag){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id=V4L2_CID_AUTO_WHITE_BALANCE;
    if(flag)
        ctrl.value=V4L2_WHITE_BALANCE_AUTO;
    else
        ctrl.value=V4L2_WHITE_BALANCE_MANUAL;
    ret=ioctl(device_,VIDIOC_S_CTRL,&ctrl);
    if(ret<0){
        std::cout<<"set camera writeblance failed!"<<std::endl;
        return false;
    }
    return true;
}
Point DrawFire(Mat &inputImg,Mat foreImg)//(复印件)
{
    vector<vector<Point> > contours_set;//保存轮廓提取后的点集
    findContours(foreImg,contours_set,CV_RETR_EXTERNAL,CV_CHAIN_APPROX_NONE);
    Point point1,point2;
    float a=0.4,b=0.75;
    float xmin1 = a*inputImg.cols, ymin1 = inputImg.rows, xmax1 = 0, ymax1 = 0;
    float xmin2 = b*inputImg.cols, ymin2 = inputImg.rows, xmax2 = a*inputImg.cols, ymax2 = 0;
    float xmin3 = inputImg.cols, ymin3 = inputImg.rows, xmax3 = b*inputImg.cols, ymax3 = 0;
    Rect finalRect1;
    Rect finalRect2;
    Rect finalRect3;
    Mat result0;
    Scalar holeColor;
    Scalar externalColor;
    int Count=0;
    vector<vector<Point> >::iterator iter = contours_set.begin();
    vector<vector<Point> > contours_left, Triangle_left;
    vector<Vec4i> hierarchy_L;
    vector<Point> approx_left;
    Point left_center1;
    vector<cv::Point2f> points2d1;
    int tlsize = 0;
    for (; iter != contours_set.end();)
    {

        approxPolyDP(*iter, approx_left, 10, true);
        contourArea(*iter);
        if (contourArea(*iter) > tlsize)
        {
            if(g_TopPointstart>0&&(g_TopPointend>150||g_TopPointend==0))
            {
                tlsize = contourArea(*iter);
                Triangle_left.clear();
                center_g(*iter, left_center1);
                Triangle_left.push_back(*iter);
                ++iter;
            }
            else
                iter=contours_set.erase(iter);
        }
        else
            iter=contours_set.erase(iter);
    }
    ///////////////////
    for (int i = 0; i < Triangle_left.size(); i++)
    {
        if (tlsize == contourArea(Triangle_left[i]))
        {
            //if(g_TopPointstart>0&&(g_TopPointend>150||g_TopPointend==0))
            //{
            center_g(Triangle_left[i], left_center1);

            //}
        }
        circle(inputImg, left_center1, 5, Scalar(0, 255, 0), -1);
        drawContours(inputImg, Triangle_left, -1, Scalar(255, 0, 0), 3);
    }
//////////////////////////////////////////////////////////////////////////////////////////
return left_center1;
}
///////////////////////////////////////////////////////////////////////////////////////////
void jianjiao(IplImage *pImage)
{

    int lWidth,lHeight;
    unsigned char *lpimage,*lpSrc;
    int i, j, m;
    int DirectSum1;
    int DirectSum2;
    int tempW;
    int tempH;
    int Count = 0;
    int FindTopPoint1 = 0;
    int FindTopPoint2 = 0;
    int ColumnL, ColumnR, BounderSpaceNum;
    int RowSumL, RowSumR;//左右边界方向，扫描的行数
    int Direction1[2][2] = {{1, -1},
                            {1, 0}};
    int Direction2[2][2] = {{1, 0},
                            {1, 1}};
    lpimage=(uchar*)pImage->imageData;
    lWidth=pImage->width;
    lHeight=pImage->height;
    int PlainAngleThreshold = 16;
    for (j = 0; j < lHeight; j++) {
        i = 0;
        while (i < lWidth) {
            Count = 1;
            lpSrc = lpimage + (j * lWidth + i);
            if (*lpSrc == 255.0) {
                if (j > 0) {
                    for (m = -4; m <= 4; m++) {
                        if ((0 <= (i + m)) && ((i + m) < lWidth)) {
                            lpSrc = lpimage + ((j - 1) * lWidth + i + m);
                            if (*lpSrc == 255.0)
                                break;
                        }
                    }
                    if (m <= 4)
                        FindTopPoint1 = 0;
                    else {
                        FindTopPoint1 = 1;
                        g_TopPointstart = i;
                    }
                } else
                    FindTopPoint1 = 1;//end of if(j>0)
            } else
                FindTopPoint1 = 0;// end of if(*lpSrc==255.0)
            if (FindTopPoint1) {
                while (1) {
                    if ((0 <= (i + Count)) && ((i + Count) < lWidth)) {
                        lpSrc = lpimage + (j * lWidth + i + Count);
                        if (*lpSrc != 0)
                            Count++;
                        else
                            break;
                    } else
                        break;
                }
                if (Count < PlainAngleThreshold) {
                    FindTopPoint2 = 1;
                    g_TopPointend = g_TopPointstart + Count - 1;
                } else
                    FindTopPoint2 = 0;

            }
            if (FindTopPoint1 && FindTopPoint2) {
                ColumnL = g_TopPointstart;
                ColumnR = g_TopPointend;
                RowSumL = 0;
                while (RowSumL <= 4) {
                    DirectSum1 = 0;
                    while (1) {
                        tempH = j + RowSumL + Direction1[DirectSum1][0];

                        tempW = ColumnL + Direction1[DirectSum1][1];
                        if (((0 <= tempW) && (tempW < lWidth)) && ((0 <= tempH) && (tempH < lHeight)))//地址有效
                        {
                            lpSrc = lpimage + (tempH * lWidth + tempW);
                            if (*lpSrc == 255.0) {
                                RowSumL++;
                                ColumnL = tempW;
                                break;
                            } else
                                DirectSum1++;
                        } else {
                            DirectSum1++;
                        }
                        if (DirectSum1 > 1) {
                            ColumnL = 0;
                            break;//退出while(1)
                        }

                    }

                    if (DirectSum1 > 1)
                        break;
                }
                RowSumR = 0;
                while (RowSumR <= 4) {
                    DirectSum2 = 1;
                    while (1) {
                        tempH = j + RowSumR + Direction2[DirectSum2][0];
                        tempW = ColumnR + Direction2[DirectSum2][1];
                        if (((0 <= tempW) && (tempW < lWidth)) && ((0 <= tempH) && (tempH < lHeight)))
                        {
                            lpSrc = lpimage + (tempH * lWidth + tempW);

                            if (*lpSrc == 255.0) {
                                RowSumR++;
                                ColumnR = tempW;
                                break;
                            } else {
                                DirectSum2--;
                            }
                        } else {
                            DirectSum2--;
                        }
                        if (DirectSum2 < 0) {
                            ColumnR = 0;

                            break;
                        }
                    }
                    if (DirectSum2 < 0)
                        break;
                }
            }
            i += Count;
        }
    }
}
Point CheckColor(Mat &inImg)
{
    Mat fireImg;
    fireImg.create(inImg.size(),CV_8UC1);
    Mat multiRGB[3];
    split(inImg,multiRGB);//拆分R G B三通道的颜色
    for(int i=0;i<inImg.rows;i++)
    {
        for(int j=0;j<inImg.cols;j++)
        {
            float B,G,R;
            B = multiRGB[0].at<uchar>(i, j); //每个像素的R,G,B值,动态地址计算法
            G = multiRGB[1].at<uchar>(i, j);
            R = multiRGB[2].at<uchar>(i, j);

            float maxValue = max(max(B, G), R);
            float minValue = min(min(B, G), R);

            //HSI中S分量计算
            double S=1-3.0*minValue/(R+G+B);

            //R > RT  R>=G>=B  S>=((255-R)*ST/RT)
            if (R > redThre &&R >= G && G>= B && S >((255 - R) * saturationTh / redThre))
            {
                fireImg.at<uchar>(i, j) = 255;
            }
            else
            {
                fireImg.at<uchar>(i, j) = 0;
            }

        }
    }
    medianBlur(fireImg,fireImg,5);//中值滤波
    dilate(fireImg, fireImg, Mat(5, 5, CV_8UC1));
    imshow("0",fireImg);
    Point dian=DrawFire(inImg,fireImg);
    return dian;
}
int main(int argc, char **argv)
{
  ros::init(argc, argv, "talker");//初始化ros,节点名称为talker
  ros::NodeHandle n;//为这个进程的节点创建一个句柄，第一个创建的 NodeHandle 会为节点进行初始化
  ros::Publisher chatter_pub = n.advertise<geometry_msgs::Twist>("chatter", 1);
  ros::Rate loop_rate(10);//允许你指定自循环的频率，它会追踪记录自上一次调用Rate::sleep()后时间的流逝
  int count = 0;
  //ros::Subscriber sub1 = n.subscribe("result", 1000, chatterCallback);
  ros::Subscriber sub2 = n.subscribe("verify", 1000, chatterCallback1);
    geometry_msgs::Twist cmd_msg;
    Mat rect1,rect2,src, R, T,E, F, RFirst, RSec, PFirst, PSec, canLeft,canLeft1,canLeft2,canRight,canRight1,canRight2,Q;
    Mat cameraMatrix1 = Mat(3, 3, CV_32FC1, Scalar::all(0));  /* 摄像机内参数矩阵 */
    Mat distCoeffs1=Mat(1, 5, CV_32FC1,Scalar::all(0));       /* 摄像机的5个畸变系数：k1,k2,p1,p2,k3 */
    Mat cameraMatrix2 = Mat(3, 3, CV_32FC1, Scalar::all(0));  /* 摄像机内参数矩阵 */
    Mat distCoeffs2=Mat(1, 5, CV_32FC1,Scalar::all(0));       /* 摄像机的5个畸变系数：k1,k2,p1,p2,k3 */
    Size imageSize(320,240);
    Rect validRoi[2], box,box2,box_result,box_result2;
    Mat rmapFirst[2], rmapSec[2], rviewFirst, rviewSec;
    int ss;
    Mat mapLx, mapLy,mapRx, mapRy;
    cameraMatrix1 = (Mat_<double>(3, 3) << 227.5447222865623, 0, 156.2591898243633,0, 227.7194778566508, 110.5704771340749,0, 0, 1);
    distCoeffs1 = (Mat_<double>(5, 1) << 0.02751717655654501, -0.008114997435119575, -0.003186517961686171, -0.001035172178891315, 0.07815783547712737);
    cameraMatrix2 = (Mat_<double>(3, 3) << 227.3917999902658, 0, 141.8110000195678,
            0, 227.4405352400969, 118.3734255739537,0, 0, 1);
    distCoeffs2 = (Mat_<double>(5, 1) << 0.03641048866842776,-0.09508752572127452,-0.00163572634434155,
            -0.0008006928518977264,0.07016841777571871);

    T = (Mat_<double>(3, 1) << -70.37621353113931,0.1572822601686296,0.2468249863927933);
    R = (Mat_<double>(3,3) <<0.9999613077234851, 0.008740972306868277, 0.0009891708993634419,-0.008742212940347861, 0.999960996171791, 0.001256920055149181,-0.0009781456145176119, -0.001265518964687477, 0.9999987208456352);//R 旋转矩阵
    Q=(Mat_<double>(4,4) <<1, 0, 0, -155.5136413574219,
            0, 1, 0, -112.8985710144043,
            0, 0, 0, 212.8627952635155,
            0, 0, 0.01420922357562481, -0.1772090365673373);
    cout<<imageSize.width<<endl;
    stereoRectify(cameraMatrix1,distCoeffs1, cameraMatrix2,distCoeffs2, imageSize, R, T, RFirst,
                  RSec, PFirst, PSec, Q, 0, 1, imageSize, &validRoi[0], &validRoi[1]);
    for (size_t i=0;i<4;i++)
    {
        for(size_t j=0;j<4;j++)
        {
            Qc(i,j)=Q.at<double>(i,j);
        }
    }
    initUndistortRectifyMap(cameraMatrix1, distCoeffs1, RFirst, PFirst,
                            imageSize, CV_16SC2, rmapFirst[0], rmapFirst[1]);
    initUndistortRectifyMap(cameraMatrix2, distCoeffs2, RSec, PSec,
                            imageSize, CV_16SC2, rmapSec[0], rmapSec[1]);
    namedWindow("Control", CV_WINDOW_AUTOSIZE);
    cvCreateTrackbar("redThre", "Control", &redThre, 255);
    cvCreateTrackbar("saturationTh", "Control", &saturationTh, 255);
    
    VideoCapture cap;
    cap.open(0);                             //打开相机，电脑自带摄像头一般编号为0，外接摄像头编号为1（但不绝对，也可能是反过来的）
        //--------------------------------------------------------------------------------------

        cap.set(CV_CAP_PROP_FRAME_WIDTH, 2560);  //设置捕获视频的宽度
        cap.set(CV_CAP_PROP_FRAME_HEIGHT, 720);  //设置捕获视频的高度
    //}
    if (!cap.isOpened())                         //判断是否成功打开相机
    {
        return -1;
    }
    Mat frame,frame_L,frame_R;

    cap >> frame;  
    double fScale = 0.5;                                //从相机捕获一帧图像
    Size dsize = Size(frame.cols*fScale, frame.rows*fScale);
    Mat imagedst = Mat(dsize, CV_32S);
    resize(frame, imagedst, dsize);
    Rect leftRect(0, 0, 640, 360);   //创建一个Rect框，属于cv中的类，四个参数代表x,y,width,height
    Rect rightRect(640, 0, 640, 360);
    //device_=open("/dev/video1",O_RDWR);
    //LinenableExpose(false);
    //LinenableWriteBalance(true);
    //LinsetExpose(20);
    //LinsetGain(16);
    
    
  while (ros::ok())//roscpp会默认生成一个SIGINT句柄，它负责处理Ctrl-C键盘操作——使得 ros::ok()返回false。
  {
      cap >> frame;                            //从相机捕获一帧图像
        resize(frame, imagedst, dsize);          //对捕捉的图像进行缩放操作
      Mat leftImg,rightImg;
        imagedst(leftRect).copyTo(leftImg);
        imagedst(rightRect).copyTo(rightImg);
      Mat rectifyImageL2, rectifyImageR2;
      remap(leftImg, rectifyImageL2, rmapFirst[0], rmapFirst[1], INTER_LINEAR);
      remap(rightImg, rectifyImageR2, rmapSec[0], rmapSec[1], INTER_LINEAR);
      
      if(waitKey(1)=='q')
          break;

//火焰识别：
center1=CheckColor(leftImg);
//center2=CheckColor(rightImg);

/*center1=CheckColor1(leftImg);//障碍块
center2=CheckColor1(rightImg);//障碍块
*/
/*Mat gray_l,gray_r;
gray_l=CheckColor3(leftImg);
gray_r=CheckColor3(rightImg);*/
imshow("left",leftImg);
imshow("right",rightImg);
/*imshow("gray_l",gray_l);
imshow("gray_r",gray_r);*/
if(command1==true)
{
//cout<<"33333333333"<<endl;
//Point center1,center2;
/*center1=CheckColor(leftImg);
center2=CheckColor(rightImg);
imshow("left",leftImg);
imshow("right",rightImg);*/
//if(rule==false&&rule2==false)
//{
      //cout<<"444444444444444"<<endl;
      //imshow("left",leftImg);
      //imshow("right",rightImg);
      delta(0,0)=center1.x;
      delta(1,0)=center1.y;
      delta(2,0)=center1.x-center2.x;
      /*center1.x=0;
      center1.y=0;
      center2.x=0;
      center2.y=0;*/
      delta(3,0)=1.0;
      ans=Qc*delta;             
      cmd_msg.linear.x=ans(0,0)/ans(3,0);
      cmd_msg.linear.y=ans(1,0)/ans(3,0)+107;
      cmd_msg.linear.z=ans(2,0)/ans(3,0);
      if(cmd_msg.linear.x<700)
{
      cmd_msg.angular.x=atan2(cmd_msg.linear.y,cmd_msg.linear.z)*180/PI;
      cmd_msg.angular.y=atan2(cmd_msg.linear.x,cmd_msg.linear.z)*180/PI;
     // cmd_msg.angular.x=20;
      //cmd_msg.angular.x=20;
      cmd_msg.linear.z=cmd_msg.linear.z-400;
      cout<<"x="<<cmd_msg.linear.x<<"y="<<cmd_msg.linear.y<<"z="<<cmd_msg.linear.z<<endl;
      chatter_pub.publish(cmd_msg);
      cout<<"cmd_msg.angular.x="<<cmd_msg.angular.x<<endl;
      cout<<"cmd_msg.angular.y="<<cmd_msg.angular.y<<endl;

      command1=false;
}
}
    ros::spinOnce();//如果程序里包含其他回调函数，最好在这里加上ros::spinOnce()这一语句
    loop_rate.sleep();//调用ros::Rate对象来休眠一段时间以使得发布频率为10Hz
    ++count;
}
  return 0;
}
void center_g(const vector<Point> contour,Point &center)
{
    Moments mu;                                                 // Get the center of a contour
    mu = moments(contour,false);
    center.x=mu.m10/mu.m00;
    center.y=mu.m01/mu.m00;
}


Point CheckColor0(Mat &inImg)
{
    bool rule1=false;
    Mat fireImg;
    fireImg.create(inImg.size(), CV_8UC1);
    Mat multiRGB[3];
    int a = inImg.channels();
    split(inImg, multiRGB); //将图片拆分成R,G,B,三通道的颜色
    for (int i = 0; i < inImg.rows; i++)
    {
        for (int j = 0; j < inImg.cols; j++)
        {
            float B, G, R;
            B = multiRGB[0].at<uchar>(i, j); //每个像素的R,G,B值,动态地址计算法
            G = multiRGB[1].at<uchar>(i, j);
            R = multiRGB[2].at<uchar>(i, j);
            float maxValue = max(max(B, G), R);
            float minValue = min(min(B, G), R); //与HSI中S分量的计算公式
            double S = (1 - 3.0*minValue / (R + G + B));//
            if (R > redThre &&R >= G && G>= B && S >((255 - R) * saturationTh / redThre))
            {
                fireImg.at<uchar>(i, j) = 255;
            }
            else
            {
                fireImg.at<uchar>(i, j) = 0;
            }
        }
    }
    medianBlur(fireImg, fireImg, 5);
    //erode(fireImg, fireImg, Mat(5, 5, CV_8UC1));
    dilate(fireImg, fireImg, Mat(5, 5, CV_8UC1));
    vector<vector<Point> > contours_left, Triangle_left;
    vector<Vec4i> hierarchy_L;
    vector<Point> approx_left;
    Point left_center1;
    vector<cv::Point2f> points2d1;
    findContours(fireImg, contours_left, hierarchy_L, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
    int tlsize = 0;
    for (int i = 0; i < contours_left.size(); i++)
    {
        approxPolyDP(contours_left[i], approx_left, 10, true);
        contourArea(contours_left[i]);

        if (contourArea(contours_left[i]) > tlsize)
        {
            tlsize = contourArea(contours_left[i]);
            Triangle_left.clear();
            center_g(contours_left[i], left_center1);
            Triangle_left.push_back(contours_left[i]);
        }
    }
    for (int i = 0; i < Triangle_left.size(); i++)
    {
        if (tlsize == contourArea(Triangle_left[i]))
        {
            center_g(Triangle_left[i], left_center1);
            RotatedRect rectangle = minAreaRect(Triangle_left[i]);
            Point2f vertex[4];
            rectangle.points(vertex);
            circle(inImg, left_center1, 5, Scalar(0,255,0),-1);
        drawContours(inImg, Triangle_left, -1, Scalar(255,0,0),3);
        }
        
    }
    return left_center1;
}

Point CheckColor1(Mat left)
{
    Point left_center1;
    vector<Mat> split_left, split_right;
    split(left, split_left);
    Mat left_diff[2];
    left_diff[0] = split_left[2] - split_left[1];
    left_diff[1] = split_left[0] - split_left[1];
    Mat thresleft;
    vector<Vec4i> hierarchy_L;
    vector<Point> approx_left;
    thresleft = left_diff[0] + left_diff[1];
    threshold(thresleft, thresleft, 0, 255, THRESH_OTSU);
    vector<vector<Point> > contours_left, Triangle_left;
    findContours(thresleft, contours_left, hierarchy_L, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
    int tlsize = 0;
    for (int i = 0; i < contours_left.size(); i++) {
        approxPolyDP(contours_left[i], approx_left, 10, true);
        if (approx_left.size() == 4 && hierarchy_L[i][2] == -1 && hierarchy_L[i][3] != -1) 
       {
            contourArea(contours_left[i]);
            if (contourArea(contours_left[i]) > tlsize) 
           {
                tlsize = contourArea(contours_left[i]);
                Triangle_left.clear();
                center_g(contours_left[i], left_center1);
                Triangle_left.push_back(contours_left[i]);
            }
        }
        
    }
    for (int i = 0; i < Triangle_left.size(); i++)
    {
        if (tlsize == contourArea(Triangle_left[i]))
        {
            center_g(Triangle_left[i], left_center1);
            RotatedRect rectangle = minAreaRect(Triangle_left[i]);
            Point2f vertex[4];
            rectangle.points(vertex);
        }
        circle(left, left_center1, 5, Scalar(0,255,0),-1);
        drawContours(left, Triangle_left, -1, Scalar(255,0,0),3);
    }
    return left_center1;
}
Mat CheckColor3(Mat &inImg)
{
    Mat kernel = getStructuringElement(MORPH_RECT, Size(5, 5));
    bool rule1=false;
    Mat fireImg;
    fireImg.create(inImg.size(), CV_8UC1);
    Mat multiRGB[3];
    int a = inImg.channels();
    split(inImg, multiRGB); //将图片拆分成R,G,B,三通道的颜色
    for (int i = 0; i < inImg.rows; i++)
    {
        for (int j = 0; j < inImg.cols; j++)
        {
            float B, G, R;
            B = multiRGB[0].at<uchar>(i, j); //每个像素的R,G,B值,动态地址计算法
            G = multiRGB[1].at<uchar>(i, j);
            R = multiRGB[2].at<uchar>(i, j);
            float maxValue = max(max(B, G), R);
            float minValue = min(min(B, G), R); //与HSI中S分量的计算公式
            double S = (1 - 3.0*minValue / (R + G + B));//
            if (R > redThre &&R >= G && G>= B && S >((255 - R) * saturationTh / redThre))
            {
                fireImg.at<uchar>(i, j) = 255;
            }
            else
            {
                fireImg.at<uchar>(i, j) = 0;
            }
        }
    }
    medianBlur(fireImg, fireImg, 3);
    //erode(fireImg, fireImg, Mat(5, 5, CV_8UC1));
    //medianBlur(segmentation, segmentation, 3);//中值滤波
            //GaussianBlur(fireImg, fireImg, Size(3, 3), 1);//高斯滤波
            morphologyEx(fireImg, fireImg, MORPH_OPEN, kernel, Point(-1, -1), 1,
                         BORDER_REPLICATE);//开操作，先腐蚀后膨胀
            morphologyEx(fireImg, fireImg, MORPH_CLOSE, kernel, Point(-1, -1), 1,
                         BORDER_REPLICATE);//闭操作，先膨胀后腐蚀
    //dilate(fireImg, fireImg, Mat(5, 5, CV_8UC1));
    vector<vector<Point> > contours_left, Triangle_left;
    vector<Vec4i> hierarchy_L;
    vector<Point> approx_left;
    Point left_center1;
    vector<cv::Point2f> points2d1;
    findContours(fireImg, contours_left, hierarchy_L, CV_RETR_TREE, CV_CHAIN_APPROX_NONE);
    int tlsize = 0;
    for (int i = 0; i < contours_left.size(); i++)
    {
        approxPolyDP(contours_left[i], approx_left, 10, true);
        contourArea(contours_left[i]);

        if (contourArea(contours_left[i]) > tlsize)
        {
            tlsize = contourArea(contours_left[i]);
            Triangle_left.clear();
            center_g(contours_left[i], left_center1);
            Triangle_left.push_back(contours_left[i]);
        }
    }
    for (int i = 0; i < Triangle_left.size(); i++)
    {
double area = contourArea(Triangle_left[static_cast<int>(i)]);
if (area<2500)
{
        if (tlsize == contourArea(Triangle_left[i]))
        {


                    
            center_g(Triangle_left[i], left_center1);
            RotatedRect rectangle = minAreaRect(Triangle_left[i]);
            Point2f vertex[4];
            rectangle.points(vertex);

            
        }
        circle(inImg, left_center1, 5, Scalar(0,255,0),-1);
        drawContours(inImg, Triangle_left, -1, Scalar(255,0,0),3);
}
    }
    return fireImg;
}
