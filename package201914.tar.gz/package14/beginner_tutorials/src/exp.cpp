#include "ros/ros.h"
#include <sstream>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/opencv.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <string.h>
#include <std_msgs/String.h>
#include "std_msgs/Int16.h"
#include <iostream>
#include <stdio.h>
#include <Eigen/Core>
#include <Eigen/Dense>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include "geometry_msgs/Twist.h"
#include <cstdio>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <fcntl.h>
#include <unistd.h>
using namespace std;
using namespace cv;
Mat frame;
int device_;
bool LingetExpose(void){
    int ret;
    struct v4l2_control ctrl;//定义结构体
    ctrl.id = V4L2_CID_EXPOSURE_AUTO;//选择项目
    ret = ioctl(device_, VIDIOC_S_CTRL, &ctrl);//调用获得参数
   // if (ret < 0){
     //   std::cout<< "set camera expose2 failed!" << std::endl;
       // return false;
    //}
//else
//{
cout<<"expose="<<ctrl.value<<"ret="<<ret<<endl;
//}
    return true;
}
bool LinenableExpose(bool flag){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id = V4L2_CID_EXPOSURE_AUTO;
    if(flag)
        ctrl.value = V4L2_EXPOSURE_AUTO;
    else
        ctrl.value = V4L2_EXPOSURE_MANUAL;
    ret = ioctl(device_, VIDIOC_S_CTRL, &ctrl);
    if (ret < 0){
        std::cout<< "set camera expose failed!" << std::endl;
        return false;
    }
    return true;
}
bool LinsetExpose(int expose){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id = V4L2_CID_EXPOSURE_ABSOLUTE;
    ctrl.value = expose;
    ret = ioctl(device_, VIDIOC_S_CTRL, &ctrl);
    if (ret < 0){
        std::cout<< "set camera expose failed!" << std::endl;
        return false;
    }
    return true;
}

bool LinsetGain(int gain){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id = V4L2_CID_GAIN;
    ctrl.value = gain;
    ret = ioctl(device_, VIDIOC_S_CTRL, &ctrl);
    if (ret < 0){
        std::cout<< "set camera expose failed!" << std::endl;
        return false;
    }
    return true;
}

bool LinenableWriteBalance(bool flag){
    int ret;
    struct v4l2_control ctrl;
    ctrl.id=V4L2_CID_AUTO_WHITE_BALANCE;
    if(flag)
        ctrl.value=V4L2_WHITE_BALANCE_AUTO;
    else
        ctrl.value=V4L2_WHITE_BALANCE_MANUAL;
    ret=ioctl(device_,VIDIOC_S_CTRL,&ctrl);
    if(ret<0){
        std::cout<<"set camera writeblance failed!"<<std::endl;
        return false;
    }
    return true;
}
int main(int argc, char **argv)
{
	ros::init(argc, argv, "exp");
	ros::NodeHandle n;
	ros::Rate loop_rate(10);
	VideoCapture cap(0);
    //cap.set(CV_CAP_PROP_FRAME_WIDTH, 2560);
    //cap.set(CV_CAP_PROP_FRAME_HEIGHT, 720);
	//cap.open(0);
//手动修改函数
/*printf("width = %.2f\n",cap.get(CV_CAP_PROP_FRAME_WIDTH));
printf("height = %.2f\n",cap.get(CV_CAP_PROP_FRAME_HEIGHT));
printf("fbs = %.2f\n",cap.get(CV_CAP_PROP_FPS));
printf("brightness = %.2f\n",cap.get(CV_CAP_PROP_BRIGHTNESS));
printf("contrast = %.2f\n",cap.get(CV_CAP_PROP_CONTRAST));
printf("saturation = %.2f\n",cap.get(CV_CAP_PROP_SATURATION));
printf("hue = %.2f\n",cap.get(CV_CAP_PROP_HUE));
printf("exposure = %.2f\n",cap.get(CV_CAP_PROP_AUTO_EXPOSURE));
*/
//
/*
cap.set(CV_CAP_PROP_FRAME_WIDTH, 640);//宽度

cap.set(CV_CAP_PROP_FRAME_HEIGHT, 480);//高度

cap.set(CV_CAP_PROP_FPS, 30);//帧率 帧/秒

cap.set(CV_CAP_PROP_BRIGHTNESS, 0.8);//亮度 0.5-1

cap.set(CV_CAP_PROP_CONTRAST,0.5);//对比度 0.5-1

cap.set(CV_CAP_PROP_SATURATION, 0.61);//饱和度 0.61-1

cap.set(CV_CAP_PROP_HUE, 0.5);//色调 0.5-1
cap.set(CV_CAP_PROP_AUTO_EXPOSURE, 1) ;// where 0.25 means "manual exposure, manual iris"
//cap.set(CV_CAP_PROP_AUTO_EXPOSURE, 0.5);//曝光 50 获取摄像头参数
printf("width = %.2f\n",cap.get(CV_CAP_PROP_FRAME_WIDTH));
printf("height = %.2f\n",cap.get(CV_CAP_PROP_FRAME_HEIGHT));
printf("fbs = %.2f\n",cap.get(CV_CAP_PROP_FPS));
printf("brightness = %.2f\n",cap.get(CV_CAP_PROP_BRIGHTNESS));
printf("contrast = %.2f\n",cap.get(CV_CAP_PROP_CONTRAST));
printf("saturation = %.2f\n",cap.get(CV_CAP_PROP_SATURATION));
printf("hue = %.2f\n",cap.get(CV_CAP_PROP_HUE));
printf("exposure = %.2f\n",cap.get(CV_CAP_PROP_AUTO_EXPOSURE));
*/
	
	
if (!cap.isOpened())                         
    {
        return -1;
    }
LinenableExpose(false);
	LinsetExpose(20);
	while (ros::ok())
	{
	cap >> frame;
    resize(frame,frame,Size(640,480)); 
	imshow("frame",frame);
if(waitKey(30)=='q')
{
return 0;
}
	//imshow("right",rightImg);
	ros::spinOnce();
	loop_rate.sleep();
	}
}

