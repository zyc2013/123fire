#include "ros/ros.h"
#include "std_msgs/Int64.h"
#include "std_msgs/String.h"
#include "std_msgs/Float64.h"
#include "geometry_msgs/Twist.h"
/*
 * */
void chatterCallback(const std_msgs::String::ConstPtr& msg)//这是一个回调函数，当接收到chatter话题的时候就会被调用。消息是以 boost shared_ptr 指针的形式传输，这就意味着你可以存储它而又不需要复制数据。
{
    //if(key->data=="a")
  ROS_INFO("I heard: [%s]", msg->data.c_str());//告诉master我们要订阅chatter话题上的消息。当有消息发布到这个话题时，ROS就会调用chatterCallback()函数。
  //ROS_INFO("I heard: [%s]", key);
}
//void chatterCallback(const std_msgs::String::ConstPtr& msg)//这是一个回调函数，当接收到chatter话题的时候就会被调用。消息是以 boost shared_ptr 指针的形式传输，这就意味着你可以存储它而又不需要复制数据。
//{
//  ROS_INFO("I heard: [%s]", msg->data.c_str());//告诉master我们要订阅chatter话题上的消息。当有消息发布到这个话题时，ROS就会调用chatterCallback()函数。
//}
//void chatterCallback(const std_msgs::Int64& b)//这是一个回调函数，当接收到chatter话题的时候就会被调用。消息是以 boost shared_ptr 指针的形式传输，这就意味着你可以存储它而又不需要复制数据。
//{
//  ROS_INFO("I heard: [%d]", b.data);//告诉master我们要订阅chatter话题上的消息。当有消息发布到这个话题时，ROS就会调用chatterCallback()函数。
//}
//void chatterCallback(const std_msgs::Float64& x)//这是一个回调函数，当接收到chatter话题的时候就会被调用。消息是以 boost shared_ptr 指针的形式传输，这就意味着你可以存储它而又不需要复制数据。
//{
//  ROS_INFO("I heard: [%f]", x.data);//告诉master我们要订阅chatter话题上的消息。当有消息发布到这个话题时，ROS就会调用chatterCallback()函数。
//}
//void chatterCallback(const geometry_msgs::Twist& cmd_msg)//这是一个回调函数，当接收到chatter话题的时候就会被调用。消息是以 boost shared_ptr 指针的形式传输，这就意味着你可以存储它而又不需要复制数据。
//{
//  ROS_INFO("I heard: [%f]", cmd_msg.linear.x);//告诉master我们要订阅chatter话题上的消息。当有消息发布到这个话题时，ROS就会调用chatterCallback()函数。
//  ROS_INFO("I heard: [%f]", cmd_msg.linear.y);
//  ROS_INFO("I heard: [%f]", cmd_msg.linear.z);
//}
int main(int argc, char **argv)
{
  ros::init(argc, argv, "listener");
  ros::NodeHandle n;
  ros::Subscriber sub = n.subscribe("chatter", 1000, chatterCallback);
  ros::spin();//入自循环，可以尽可能快的调用消息回调函数
  return 0;
}

